const contractAddress = "YOUR_DEPLOYED_CONTRACT_ADDRESS";
const abi = [
  "function postMessage(string memory _text) public",
  "function getMessages() public view returns (tuple(address sender, string text, uint256 timestamp)[])"
];

async function postMessage() {
  const messageInput = document.getElementById("message");
  const text = messageInput.value;
  if (!text) return alert("Enter a message");

  if (typeof window.ethereum === 'undefined') return alert("MetaMask required");
  await ethereum.request({ method: 'eth_requestAccounts' });

  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = provider.getSigner();
  const contract = new ethers.Contract(contractAddress, abi, signer);

  try {
    const tx = await contract.postMessage(text);
    await tx.wait();
    messageInput.value = "";
    loadMessages();
  } catch (err) {
    alert("Error: " + err.message);
  }
}

async function loadMessages() {
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const contract = new ethers.Contract(contractAddress, abi, provider);
  const messages = await contract.getMessages();
  const messagesList = document.getElementById("messages");
  messagesList.innerHTML = "";
  messages.slice().reverse().forEach(msg => {
    const li = document.createElement("li");
    li.textContent = `@${msg.sender.slice(0, 6)}: ${msg.text}`;
    messagesList.appendChild(li);
  });
}

loadMessages();
