const hre = require("hardhat");

async function main() {
  const HelloChat = await hre.ethers.getContractFactory("HelloChat");
  const helloChat = await HelloChat.deploy();
  await helloChat.deployed();

  console.log("HelloChat deployed to:", helloChat.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
